#
# Decription: This method launches the VM provisioning job
#

$evm.root["miq_provision_task"].execute
